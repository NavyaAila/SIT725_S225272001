const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

app.get('/hello', (req, res) => {
  res.send('Hello from Express server!');
});

app.get('/add', (req, res) => {
  const x = parseFloat(req.query.x);
  const y = parseFloat(req.query.y);

  if (Number.isNaN(x) || Number.isNaN(y)) {
    return res.status(400).json({ error: 'x and y must be numbers (send as query params)' });
  }

  const sum = x + y;
  return res.json({ x, y, sum });
});

app.post('/add', (req, res) => {
  const { x, y } = req.body;
  const a = parseFloat(x);
  const b = parseFloat(y);

  if (Number.isNaN(a) || Number.isNaN(b)) {
    return res.status(400).json({ error: 'x and y must be numbers in request body' });
  }

  return res.json({ x: a, y: b, sum: a + b });
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});
